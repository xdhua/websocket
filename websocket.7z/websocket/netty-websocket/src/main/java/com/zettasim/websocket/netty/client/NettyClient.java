package com.zettasim.websocket.netty.client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.websocketx.WebSocketClientHandshaker;
import io.netty.handler.codec.http.websocketx.WebSocketClientHandshakerFactory;
import io.netty.handler.codec.http.websocketx.WebSocketVersion;
import io.netty.handler.stream.ChunkedWriteHandler;
import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @ClassName NettyClient
 * @Author hxd
 * @Date 2023/11/30 14:53
 **/
@Slf4j
public class NettyClient {

    static Bootstrap bootstrap = new Bootstrap();

    /**
     * 处理事件的线程池
     */
    static EventLoopGroup group = new NioEventLoopGroup(1);

    static {
        bootstrap.group(group).channel(NioSocketChannel.class);
    }

    WebSocketClientHandshaker handShaker;

    ChannelFuture handshakeFuture;

    WebSocketIoHandler handler;

    String host;

    int port;

    /**
     * 网络通道
     */
    Channel channel;

    public void init() throws URISyntaxException {
        String URL = this.host + ":" + this.port + "/test";
        URI uri = new URI(URL);
        handler = new WebSocketIoHandler(WebSocketClientHandshakerFactory.newHandshaker(uri, WebSocketVersion.V13, null, true, new DefaultHttpHeaders()));
        bootstrap.option(ChannelOption.TCP_NODELAY, true)
                .option(ChannelOption.SO_TIMEOUT, 60000)
                .option(ChannelOption.SO_BROADCAST, true)
                .option(ChannelOption.SO_KEEPALIVE, true)
                .handler(new ChannelInitializer<SocketChannel>() {

                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new HttpClientCodec());
                        pipeline.addLast(new ChunkedWriteHandler());
                        pipeline.addLast(new HttpObjectAggregator(1024 * 1024));
                        pipeline.addLast(handler);
                    }
                });
    }

    /**
     * 连接
     */
    public void connect() {
        try {
            try {
                ChannelFuture future = bootstrap.connect("ws//" + this.host, this.port).sync();
                this.channel = future.channel();
            } catch (Exception e) {
                log.error("创建channel失败", e);
            }
        } catch (Exception e) {
            log.error("连接服务失败", e);
        } finally {
            this.handshakeFuture = handler.handshakeFuture();
        }
    }

    /**
     * 关闭
     */
    public void close() {
        this.channel.close();
    }
}

