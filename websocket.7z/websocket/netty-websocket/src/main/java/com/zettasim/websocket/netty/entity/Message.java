package com.zettasim.websocket.netty.entity;

import com.alibaba.fastjson2.JSONObject;

/**
 * @ClassName Message
 * @Author hxd
 * @Date 2023/11/24 14:41
 **/
public class Message {
    private String type;

    private JSONObject data;
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public JSONObject getData() {
        return data;
    }

    public void setData(JSONObject data) {
        this.data = data;
    }


}
