package com.zettasim.websocket.netty.service;

import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

/**
 * @ClassName NettyWebSocket
 * @Author hxd
 * @Date 2023/11/27 16:20
 **/
public interface NettyWebSocket {

    /**
     *  操作信息
     * @param message
     * @param channel
     */
    public void handleMessage(String message, Channel channel);

    /**
     * 是否支持
     * @param uri
     * @return
     */
     boolean support(String uri);
}
