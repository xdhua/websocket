package com.zettasim.websocket.netty.service.impl;

import com.alibaba.fastjson2.JSON;
import com.zettasim.websocket.common.request.SocketRequest;
import com.zettasim.websocket.netty.service.NettyWebSocket;
import com.zettasim.websocket.netty.util.ServiceDispatch;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

/**
 * @ClassName OrderServiceImpl
 * @Author hxd
 * @Date 2023/11/21 16:48
 **/
public class OrderServiceImpl implements NettyWebSocket {

    private final String type = "order";

    @Override
    public void handleMessage(String message, Channel channel) {
        SocketRequest socketRequest = JSON.parseObject(message, SocketRequest.class);
        final Channel channel1 = ServiceDispatch.getChannel(socketRequest.getUserId());
        if (null != channel1) {
            channel1.writeAndFlush(new TextWebSocketFrame(type+message));
        } else {
            channel.writeAndFlush(new TextWebSocketFrame(type+message));
        }
    }

    @Override
    public boolean support(String uri) {
        return type.equals(uri);
    }
}
