package com.zettasim.websocket.netty.util;

import com.alibaba.fastjson2.JSON;
import com.zettasim.websocket.common.request.SocketRequest;
import com.zettasim.websocket.common.response.ApiResult;
import com.zettasim.websocket.netty.service.NettyWebSocket;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;

import java.util.Map;
import java.util.ServiceLoader;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @ClassName ServiceDispatch
 * @Author hxd
 * @Date 2023/11/24 11:07
 **/
public class ServiceDispatch {
    private static final ServiceLoader<NettyWebSocket> services = ServiceLoader.load(NettyWebSocket.class);

    private static final Map<String,Channel> CHANNEL_MAP = new ConcurrentHashMap<>();

    private ServiceDispatch(){

    }

    public static void dispatch(String message, Channel channel) {
        if ("".equals(message) || null == message) {
            ApiResult<Object> build = ApiResult.builder().msg("数据不能为空！！").code(500).build();
            channel.writeAndFlush(new TextWebSocketFrame(JSON.toJSONString(build)));
            return;
        }
        SocketRequest message1 = JSON.parseObject(message, SocketRequest.class);
        for (NettyWebSocket service : services) {
            if (service.support(message1.getType())) {
                service.handleMessage(message, channel);
                break;
            }
        }
    }

    public static void cacheChannel(String userId, Channel channel) {
        CHANNEL_MAP.put(userId, channel);
    }

    public static Channel getChannel(String userId){
        if ("".equals(userId) || null == userId) {
            return null;
        }
        final Channel channel = CHANNEL_MAP.get(userId);
        if (channel.isOpen()) {
            return channel;
        } else {
            CHANNEL_MAP.remove(userId);
        }
        return null;
    }


}
