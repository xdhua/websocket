package com.zettasim.websocket.spring.loader;

import com.alibaba.fastjson2.JSON;
import com.zettasim.websocket.common.request.SocketRequest;
import com.zettasim.websocket.common.response.ApiResult;
import com.zettasim.websocket.spring.service.WebSocketService;

import javax.websocket.Session;
import java.io.IOException;
import java.util.ServiceLoader;

/**
 * @ClassName ServiceDispatch
 * @Author hxd
 * @Date 2023/11/24 11:07
 **/
public class ServiceDispatch {
    private static final ServiceLoader<WebSocketService> services = ServiceLoader.load(WebSocketService.class);

    private ServiceDispatch(){

    }

    public static void dispatch(String message, Session session) throws IOException {
         if ("".equals(message) || null == message) {
              ApiResult<Object> build = ApiResult.builder().msg("数据不能为空！！").code(500).build();
             session.getBasicRemote().sendText(JSON.toJSONString(build));
             return;
        }
        SocketRequest message1 = JSON.parseObject(message, SocketRequest.class);
        for (WebSocketService service : services) {
            if (service.support(message1.getType())) {
                service.handleMessage(JSON.toJSONString(message1.getMessage()), session);
                break;
            }
        }
    }

}
