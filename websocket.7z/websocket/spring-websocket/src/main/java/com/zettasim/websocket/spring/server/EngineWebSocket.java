package com.zettasim.websocket.spring.server;

import com.zettasim.websocket.spring.loader.ServiceDispatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;


/**
 * @ClassName EngineWebSocket
 * @Author hxd
 * @Date 2023/11/27 10:45
 **/

@ServerEndpoint("/ws")
@Component
@Slf4j
public class EngineWebSocket {

    @OnOpen
    public void onOpen(Session session) {
        session.setMaxIdleTimeout(0);

    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose(Session session, @PathParam("userId") String userId) throws IOException {
        log.info("||||||||||" + session.getId());
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) throws IOException {
        log.info("-------------------------------"+ session.getId());
        ServiceDispatch.dispatch(message, session);
    }

    /**
     * 发生错误时调用
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.error("error ++++" +session.getId());
    }
}
