package com.zettasim.websocket.spring.service;

import javax.websocket.Session;
import java.io.IOException;

/**
 * @ClassName WebSocketService
 * @Author hxd
 * @Date 2023/11/27 16:36
 **/
public interface WebSocketService {

    /**
     * 接受信息操作
     * @param message
     * @param session
     */
    public void handleMessage(String message, Session session) throws IOException;

    /**
     * 是否支持
     * @param uri
     * @return
     */
    boolean support(String uri);
}
