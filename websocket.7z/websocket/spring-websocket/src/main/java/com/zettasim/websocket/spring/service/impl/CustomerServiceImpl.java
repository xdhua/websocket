package com.zettasim.websocket.spring.service.impl;

import com.zettasim.websocket.spring.service.WebSocketService;

import javax.websocket.Session;
import java.io.IOException;

/**
 * @ClassName CustomerServiceImpl
 * @Author hxd
 * @Date 2023/11/24 11:04
 **/
public class CustomerServiceImpl implements WebSocketService {

    private final String type = "customer";

    @Override
    public void handleMessage(String message, Session session) throws IOException {
        session.getBasicRemote().sendText(message);
    }

    @Override
    public boolean support(String uri) {
        return type.equals(uri);
    }
}
