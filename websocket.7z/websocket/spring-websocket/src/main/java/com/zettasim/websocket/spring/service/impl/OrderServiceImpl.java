package com.zettasim.websocket.spring.service.impl;

import com.zettasim.websocket.spring.service.WebSocketService;

import javax.websocket.Session;
import java.io.IOException;

/**
 * @ClassName OrderServiceImpl
 * @Author hxd
 * @Date 2023/11/21 16:48
 **/
public class OrderServiceImpl implements WebSocketService {

    private final String type = "order";

    @Override
    public void handleMessage(String message, Session session) throws IOException {
        session.getBasicRemote().sendText(message);
    }

    @Override
    public boolean support(String uri) {
        return type.equals(uri);
    }
}
