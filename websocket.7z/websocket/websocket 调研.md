# websocket 调研

## websocket

WebSocket是一种与[HTTP](https://zh.wikipedia.org/wiki/超文本传输协议)不同的协议。两者都位于[OSI模型](https://zh.wikipedia.org/wiki/OSI模型)的[应用层](https://zh.wikipedia.org/wiki/应用层)，并且都依赖于[传输层](https://zh.wikipedia.org/wiki/传输层)的TCP协议。 虽然它们不同，但是RFC 6455中规定：`it is designed to work over HTTP ports 80 and 443 as well as to support HTTP proxies and intermediaries`（WebSocket通过HTTP端口80和443进行工作，并支持HTTP代理和中介），从而使其与HTTP协议兼容。 为了实现兼容性，WebSocket握手使用HTTP Upgrade头[[1\]](https://zh.wikipedia.org/wiki/WebSocket#cite_note-1)从HTTP协议更改为WebSocket协议。

WebSocket协议支持Web[浏览器]（或其他客户端应用程序）与Web[服务器]之间的交互，具有较低的开销，便于实现客户端与服务器的实时数据传输。 服务器可以通过标准化的方式来实现，而无需客户端首先请求内容，并允许消息在保持连接打开的同时来回传递。通过这种方式，可以在客户端和服务器之间进行双向持续对话。

## websocket的优点

以前web server实现推送技术或者即时通讯，用的都是轮询（polling），在特点的时间间隔（比如1秒钟）由浏览器自动发出请求，将服务器的消息主动的拉回来，在这种情况下，我们需要不断的向服务器发送请求，然而HTTP request 的header是非常长的，里面包含的数据可能只是一个很小的值，这样会占用很多的带宽和服务器资源。

而最比较新的技术去做轮询的效果是Comet – 用了AJAX。但这种技术虽然可达到全双工通信，但依然需要发出请求(reuqest)。

WebSocket API最伟大之处在于服务器和客户端可以在给定的时间范围内的任意时刻，相互推送信息。 浏览器和服务器只需要要做一个握手的动作，在建立连接之后，服务器可以主动传送数据给客户端，客户端也可以随时向服务器发送数据。 此外，服务器与客户端之间交换的标头信息很小。

WebSocket并不限于以Ajax(或XHR)方式通信，因为Ajax技术需要客户端发起请求，而WebSocket服务器和客户端可以彼此相互推送信息；

因此从服务器角度来说，websocket有以下好处：

1. 节省每次请求的header
   http的header一般有几十字节
2. Server Push
   服务器可以主动传送数据给客户端

## http与websocket

ttp连接为一次请求一次响应(request->response)，必须为同步调用方式。
而websocket为一次连接以后，会建立tcp连接，后续客户端与服务器交互为全双工方式的交互方式，客户端可以发送消息到服务端，服务端也可将消息发送给客户端。

[![http,websocket对比](https://lrwinx.github.io/images/compareWebsocketHttp.png)](https://lrwinx.github.io/images/compareWebsocketHttp.png)



### 连接数

linux：

- 客户端，服务器部署在同一台机器，取决于可用端口数量；
- 客户端，服务器部署在不同机器上，在进行高并发TCP连接处理时，最高的并发数量都要受到系统对用户单一进程同时可打开文件数量的限制(这是因为系统为每个TCP连接都要创建一个socket句柄，每个socket句柄同时也是一个文件句柄) 资料参考[Linux下高并发socket最大连接数所受的各种限制 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/165554130)



## 2. 技术选型

-  基于spring快速编程  spring-boot-starter-websocket
-  netty-websocket 

### 2.1 基于spring-boot-starter-websocket 代码实现

pom引用

~~~xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-websocket</artifactId>
        </dependency>
~~~

~~~ java
// 设置终点传输对象
@Configuration
public class WebsocketConfig {
    @Bean
    public ServerEndpointExporter serverEndpointExporter(){
        return new ServerEndpointExporter();
    }
}
~~~

关键代码说明

~~~ java
// 设置业务监听路径, 可设置业务相关数据
@ServerEndpoint("/ws/{userId}/{jobId}/")
@Component
@Slf4j
public class EngineWebSocket {

     /**
     * 建立连接调用
     * @PathParam 使用 该注解获取路径中数据
     */
    @OnOpen
    public void onOpen(Session session) {
        session.setMaxIdleTimeout(0);

    }

    /**
     * 连接关闭调用的方法
     * @PathParam 使用 该注解获取路径中数据
     */
    @OnClose
    public void onClose(Session session, @PathParam("userId") String userId) throws IOException {
        log.info("||||||||||" + session.getId());
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) throws IOException {
        log.info("-------------------------------"+ session.getId());
        ServiceDispatch.dispatch(message, session);
    }

    /**
     * 发生错误时调用
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.error("error ++++" +session.getId());
    }
~~~



~~~java
// 业务处理接口
public interface WebSocketService {

    /**
     * 接受信息操作
     * @param message
     * @param session
     */
    public void handleMessage(String message, Session session) throws IOException;

    /**
     * 是否支持
     * @param uri
     * @return
     */
    boolean support(String uri);
}
~~~

~~~ java
public class OrderServiceImpl implements WebSocketService {

    private final String type = "order";

    @Override
    public void handleMessage(String message, Session session) throws IOException {
        session.getBasicRemote().sendText(message);
    }

    @Override
    public boolean support(String uri) {
        return type.equals(uri);
    }
}

~~~

~~~ java
// 业务选择
public class ServiceDispatch {
    private static final ServiceLoader<WebSocketService> services = ServiceLoader.load(WebSocketService.class);

    private ServiceDispatch(){

    }

    public static void dispatch(String message, Session session) throws IOException {
         if ("".equals(message) || null == message) {
              ApiResult<Object> build = ApiResult.builder().msg("数据不能为空！！").code(500).build();
             session.getBasicRemote().sendText(JSON.toJSONString(build));
             return;
        }
        SocketRequest message1 = JSON.parseObject(message, SocketRequest.class);
        for (WebSocketService service : services) {
            if (service.support(message1.getType())) {
                service.handleMessage(JSON.toJSONString(message1.getMessage()), session);
                break;
            }
        }
    }

}
~~~



客户端 实现：

~~~javascript
<html>
<head lang="zh-cn">
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<script type="text/javascript">
    var socket;
    if (!window.WebSocket) {
        window.WebSocket = window.MozWebSocket;
    }
    if (window.WebSocket) {
        socket = new WebSocket("ws://192.168.10.145:8555/ws/123/456/");
        socket.onmessage = function (event) {
            var element = document.getElementById(123);
            element.append("<div> " + event.data + "</div>");
            console.log(event.data);
        };
        socket.onopen = function (event) {
            console.log("websocket 打开了");
        };
        socket.onclose = function (event) {
            console.log("websocket 关闭了");
        };
    }

    function send(message) {
        if (!window.WebSocket) {
            return;
        }
        if (socket.readyState == WebSocket.OPEN) {
            let request = "{\"type\":\"order\", \"message\":{\"message\": \""+message+"\"}, \"userId\":\"45678\"}";
            socket.send(request);
        } else {
            alert("The socket is not open.");
        }
    }
</script>
<form onsubmit="return false;">
    <input type="text" name="message" value="Hello, World!"/>
    <input type="button" value="Send Web Socket Data" onclick="send(this.form.message.value)"/>
    <div id = '123'></div>
</form>
</body>
</html>
~~~



### 2.2 netty 实现

pom

~~~xml
        <dependency>
            <groupId>io.netty</groupId>
            <artifactId>netty-all</artifactId>
            <version>5.0.0.Alpha2</version>
        </dependency>
        <dependency>
            <groupId>ch.qos.logback</groupId>
            <artifactId>logback-classic</artifactId>
        </dependency>
        <dependency>
            <groupId>ch.qos.logback</groupId>
            <artifactId>logback-core</artifactId>
        </dependency>
        <dependency>
            <groupId>com.jcraft</groupId>
            <artifactId>jzlib</artifactId>
            <version>1.1.2</version>
        </dependency>
        <dependency>
            <groupId>commons-codec</groupId>
            <artifactId>commons-codec</artifactId>
            <version>1.10</version>
        </dependency>
        <dependency>
            <groupId>com.alibaba.fastjson2</groupId>
            <artifactId>fastjson2</artifactId>
            <version>2.0.42</version>
        </dependency>
~~~

基础代码：

服务

~~~java
    private static final int PORT = 8988;
	// 开启服务
    public static void main(String[] args) throws Exception {
        //Acceptor 线程池，负责处理客户端的 TCP 连接请求
        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        //真正负责 I/O 读写操作的线程组，通过 ServerBootstrap 的 group 方法进行设置，用于后续的 Channel 绑定
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(new WebSocketServerInitializer());
            Channel ch = b.bind(PORT).sync().channel();
            ch.closeFuture().sync();
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
~~~

~~~java
    @Override
    public void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline pipeline = ch.pipeline();
        // 解码器
        pipeline.addLast(new HttpServerCodec());
        // 设置聚合器
        pipeline.addLast(new HttpObjectAggregator(65536));
        // 压缩器
        pipeline.addLast(new WebSocketServerCompressionHandler());
        // 操作器
        pipeline.addLast(new WebSocketServerHandler());
    }
~~~

 socket 操作

~~~java

    private WebSocketServerHandshaker handShaker;

    @Override
    public void messageReceived(ChannelHandlerContext ctx, Object msg) {
        if (msg instanceof FullHttpRequest) {
            handleHttpRequest(ctx, (FullHttpRequest) msg);
        } else if (msg instanceof WebSocketFrame) {
            handleWebSocketFrame(ctx, (WebSocketFrame) msg);
        }
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    /**
     *  握手前check
     * @param ctx
     * @param req
     */
    private void handleHttpRequest(ChannelHandlerContext ctx, FullHttpRequest req) {
        // Handle a bad request.
        if (!req.decoderResult().isSuccess()) {
            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, BAD_REQUEST));
            return;
        }

        // Allow only GET methods.
        if (req.method() != GET) {
            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, FORBIDDEN));
            return;
        }
        final String uri = req.uri();

        if ("/".equals(uri)) {
            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, NOT_FOUND));
            return;
        }

        QueryStringDecoder queryStringDecoder = new QueryStringDecoder(uri);
        final Map<String, List<String>> parameters = queryStringDecoder.parameters();
        if (parameters.containsKey("userId")) {
            ServiceDispatch.cacheChannel(parameters.get("userId").get(0), ctx.channel());
        }

//        ChannelGroup group = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
//
//        final String[] split = uri.split("/");


//        if ("/favicon.ico".equals(req.uri()) || ("/".equals(req.uri()))) {
//            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, NOT_FOUND));
//            return;
//        }
//
//        QueryStringDecoder queryStringDecoder = new QueryStringDecoder(req.uri());
//        Map<String, List<String>> parameters = queryStringDecoder.parameters();

//        if (parameters.size() == 0 || !parameters.containsKey(HTTP_REQUEST_STRING)) {
//            System.err.printf(HTTP_REQUEST_STRING + "参数不可缺省");
//            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, NOT_FOUND));
//            return;
//        }
//
//        client = RequestService.clientRegister(parameters.get(HTTP_REQUEST_STRING).get(0));
//        if (client.getRoomId() == 0) {
//            System.err.printf("房间号不可缺省");
//            sendHttpResponse(ctx, req, new DefaultFullHttpResponse(HTTP_1_1, NOT_FOUND));
//            return;
//        }

        // 房间列表中如果不存在则为该频道,则新增一个频道 ChannelGroup
//        if (!channelGroupMap.containsKey(client.getRoomId())) {
//            channelGroupMap.put(client.getRoomId(), new DefaultChannelGroup(GlobalEventExecutor.INSTANCE));
//        }
//        // 确定有房间号,才将客户端加入到频道中
//        channelGroupMap.get(client.getRoomId()).add(ctx.channel());

        //设置握手
        WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(getWebSocketLocation(req), null, true);
        handShaker = wsFactory.newHandshaker(req);
        if (handShaker == null) {
            WebSocketServerHandshakerFactory.sendUnsupportedVersionResponse(ctx.channel());
        } else {
            ChannelFuture channelFuture = handShaker.handshake(ctx.channel(), req);
            // 握手成功之后,业务逻辑
            if (channelFuture.isSuccess()) {
                log.info("连接成功！！");

            }
        }
    }

    private void broadcast(ChannelHandlerContext ctx, WebSocketFrame frame) {
        String message = ((TextWebSocketFrame) frame).text();
        ServiceDispatch.dispatch(message, ctx.channel());
    }

    private void handleWebSocketFrame(ChannelHandlerContext ctx, WebSocketFrame frame) {

        if (frame instanceof CloseWebSocketFrame) {
            handShaker.close(ctx.channel(), (CloseWebSocketFrame) frame.retain());
            return;
        }
        if (frame instanceof PingWebSocketFrame) {
            ctx.channel().write(new PongWebSocketFrame(frame.content().retain()));
            return;
        }
        if (!(frame instanceof TextWebSocketFrame)) {
            throw new UnsupportedOperationException(String.format("%s frame types not supported", frame.getClass().getName()));
        }

        broadcast(ctx, frame);
    }

    private static void sendHttpResponse(ChannelHandlerContext ctx, FullHttpRequest req, FullHttpResponse res) {
        if (res.status().code() != 200) {
            ByteBuf buf = Unpooled.copiedBuffer(res.status().toString(), CharsetUtil.UTF_8);
            res.content().writeBytes(buf);
            buf.release();
            HttpHeaderUtil.setContentLength(res, res.content().readableBytes());
        }

        ChannelFuture f = ctx.channel().writeAndFlush(res);
        if (!HttpHeaderUtil.isKeepAlive(req) || res.status().code() != 200) {
            f.addListener(ChannelFutureListener.CLOSE);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.error("------------------"+ ctx.channel().id() + cause );
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        Channel incoming = ctx.channel();
        log.info("收到" + incoming.remoteAddress() + " 握手请求");

    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        Channel incoming = ctx.channel();
        log.info("收到" + incoming.remoteAddress() + " 端断开请求");
    }

    private static String getWebSocketLocation(FullHttpRequest req) {
        String location = req.headers().get(HOST) + req.uri();
        return "ws://" + location;
    }
~~~



~~~ javascript
<html>
<head lang="zh-cn">
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<script type="text/javascript">
    var socket;
    if (!window.WebSocket) {
        window.WebSocket = window.MozWebSocket;
    }
    if (window.WebSocket) {
        socket = new WebSocket("ws://192.168.10.145:8988?userId=45678");
        // socket = new WebSocket("ws://localhost:8988/websocket/?request=e2lkOjE7cmlkOjI2O3Rva2VuOiI0MzYwNjgxMWM3MzA1Y2NjNmFiYjJiZTExNjU3OWJmZCJ9");
        socket.onmessage = function (event) {
            var element = document.getElementById(123);
            element.append("<div> " + event.data + "</div>");
            console.log(event.data);
        };
        socket.onopen = function (event) {
            console.log("websocket 打开了");
        };
        socket.onclose = function (event) {
            console.log("websocket 关闭了");
        };
    }

    function send(type,message) {
        if (!window.WebSocket) {
            return;
        }
        if (socket.readyState == WebSocket.OPEN) {
            let request = "{\"type\":\""+type+"\", \"message\":{\"message\": \""+message+"\"}, \"userId\":\"123456\"}";
            socket.send(request);
        } else {
            alert("The socket is not open.");
        }
    }
</script>
<form onsubmit="return false;">
       <select id="skills" name="skills">
            <option value="order" selected>order</option>
            <option value="customer">customer</option>
        </select>
    <input type="text" name="message" value="Hello, World!"/>
    <input type="button" value="Send Web Socket Data" onclick="send(this.form.skills[this.form.skills.selectedIndex].value,this.form.message.value)"/>
    <div id = '123'></div>
</form>
</body>
</html>
~~~

说明： 打开两个连接，服务器根据连接中参数进行连接通道绑定，  当服务端接受到信息根据userId获取通道地址，将信息通过通道传送给绑定客户端

## 安全认证：

客户端可以将认证信息放在url 中，服务端接收到连接信息，进行check

## 3.支持场景

1. 客户端点对点消息推送，例如：张三给李四发信息，李四回复
2. 服务端广播，例如：程序运行报错，将消息推送给所有关注人客户端
3. 服务器推送单点，张三发送数据到服务器，处理完成后在推送给张三

## 4. 代码地址

http://192.168.1.102/xiaodong.hu/websocket.git
