package com.zettasim.websocket.common.request;

import lombok.Data;

/**
 * @ClassName SocketRequest
 * @Author hxd
 * @Date 2023/11/27 11:24
 **/
@Data
public class SocketRequest{

    /**
     *  类型对应相关业务
     */
    private String type;

    /**
     *  对应任务Id
     */
    private String jobId;

    /**
     *  对应任务信息
     */
    private String message;

    /**
     *  要发给的用户id
     */
    private String userId;

    private boolean broadcast;
}
