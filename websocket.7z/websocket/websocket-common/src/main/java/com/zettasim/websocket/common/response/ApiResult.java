package com.zettasim.websocket.common.response;

import lombok.Builder;
import lombok.Data;

/**
 * @ClassName ApiResult
 * @Author hxd
 * @Date 2023/11/27 11:14
 **/

@Data
@Builder
public class ApiResult<T> {

    private int code;
    private String msg;
    private T data;
}
